import sys, os

try:
    Version = sys.version[:6]
    Message = f"System Installed python version : {Version}"
    print(Message)
except Exception as e:
    print(f"{e}")
    pass
    
try:
    import xlwings as xw
except (ModuleNotFoundError, ImportError):
    print("xlwings module not found")
    os.system(f"{sys.executable} -m pip install -U xlwings")
finally:
    import xlwings as xw

try:
    import numpy as np 
except (ModuleNotFoundError, ImportError):
    print("numpy module not found")
    os.system(f"{sys.executable} -m pip install -U numpy")
finally:
    import numpy as np 
 
try:
    from googleapiclient import discovery
except (ModuleNotFoundError, ImportError):
    print("googleapiclient module not found")
    os.system(f"{sys.executable} -m pip install -U google-api-python-client")
finally:
    from googleapiclient import discovery
    
try:
    import gspread
except (ModuleNotFoundError, ImportError):
    print("gspread module not found")
    os.system(f"{sys.executable} -m pip install -U gspread")
finally:
    import gspread
        
try:
    from gspread_dataframe import set_with_dataframe
except (ModuleNotFoundError, ImportError):
    print("gspread_dataframe module not found")
    os.system(f"{sys.executable} -m pip install -U gspread_dataframe")
finally:
    from gspread_dataframe import set_with_dataframe
    
try:
    from oauth2client.service_account import ServiceAccountCredentials
except (ModuleNotFoundError, ImportError):
    print("oauth2client module not found")
    os.system(f"{sys.executable} -m pip install -U oauth2client")
finally:
    from oauth2client.service_account import ServiceAccountCredentials
    
try:
    import pandas as pd
except (ModuleNotFoundError, ImportError):
    print("pandas module not found")
    os.system(f"{sys.executable} -m pip install -U pandas")
finally:
    import pandas as pd
    
try:
    import scipy
except (ModuleNotFoundError, ImportError):
    print("scipy module not found")
    os.system(f"{sys.executable} -m pip install -U scipy")
finally:
    import scipy

try:
    from kiteconnect import KiteConnect, KiteTicker
except (ModuleNotFoundError, ImportError):
    print("KiteConnect module not found")
    os.system(f"{sys.executable} -m pip install -U kiteconnect")
    print(f"Please install c_plus wheel also using below command")
    print(f"pip install c_plus_plus.whl")
finally:
    from kiteconnect import KiteConnect, KiteTicker 

try:
    import msgpack
except (ModuleNotFoundError, ImportError):
    print("msgpack module not found")
    os.system(f"{sys.executable} -m pip install -U msgpack")
finally:
    import msgpack
    
try:
    import tgcrypto
except (ModuleNotFoundError, ImportError):
    print("tgcrypto module not found")
    os.system(f"{sys.executable} -m pip install -U tgcrypto")
finally:
    import tgcrypto
    
try:
    import boltons
except (ModuleNotFoundError, ImportError):
    print("boltons module not found")
    os.system(f"{sys.executable} -m pip install -U boltons")
finally:
    import boltons
    
try:
    import environs
except (ModuleNotFoundError, ImportError):
    print("environs module not found")
    os.system(f"{sys.executable} -m pip install -U environs")
finally:
    import environs

try:
    import sourcedefender
except (ModuleNotFoundError, ImportError):
    print("sourcedefender module not found")
    os.system(f"{sys.executable} -m pip install -U sourcedefender")
finally:
    import sourcedefender
    
try:    
    import OptionChain_Core_V1_002
except Exception as e:
    print(f"OptionChain_Core_V1_002.pye file not found/corrupted, please download the latest file from tinyurl.com/pythontrader : {e}")